import React from 'react';

class Counter extends React.Component {
  constructor(props) {
    super(props);
    this.onInputChange = this.onInputChange.bind(this);
    this.onResetLocal = this.onResetLocal.bind(this);
    this.state = {
      inputNumber: 0
    };
  } 
  
  onInputChange(event) {
    this.setState({
      inputNumber: parseInt(event.target.value)
    });
  }

  onResetLocal() {
    this.props.onReset(this.state.inputNumber);
  }

  render() {
    const {count, onDecrement, onIncrement, clicks} = this.props;
    return(
      <div>
        <div>
          <button onClick={onDecrement}>-</button><span>{count}</span><button onClick={onIncrement}>+</button><br />
          <b>Times the increment/decrement buttons have been clicked: {clicks} </b><br />
          <input type={'number'} onChange={this.onInputChange}/><button onClick={this.onResetLocal}>Change Count Number</button>
        </div>
      </div>
    );
  }
}

export default Counter;



